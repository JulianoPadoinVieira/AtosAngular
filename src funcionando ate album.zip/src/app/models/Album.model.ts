export class Album {
  public userId: number;
  public id: number;
  public title: string;
}
