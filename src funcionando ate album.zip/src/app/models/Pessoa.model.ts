export class Pessoa {
  nome: string;
  papel: string;

  constructor(nome: string, papel?: string) {
    this.nome = nome;
    this.papel = papel;
  }
}
