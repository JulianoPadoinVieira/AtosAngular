export class Photo {
  public albumId: number;
  public id: number;
  public title: string;
  public url: string;
  public thumbnailUrl: string;
}
